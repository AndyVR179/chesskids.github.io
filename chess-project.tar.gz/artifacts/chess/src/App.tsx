import { Switch, Route, Router as WouterRouter, Redirect } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider, useAuth } from "@/lib/auth";
import { Layout } from "@/components/layout";
import NotFound from "@/pages/not-found";

import Home from "@/pages/home";
import Login from "@/pages/login";
import Register from "@/pages/register";
import Dashboard from "@/pages/dashboard";
import Play from "@/pages/play";
import PlayBot from "@/pages/play-bot";
import Friends from "@/pages/friends";
import Profile from "@/pages/profile";
import Leaderboard from "@/pages/leaderboard";

const queryClient = new QueryClient();

function ProtectedRoute({ component: Component, ...rest }: any) {
  const { isAuthenticated, isLoading } = useAuth();
  if (isLoading) return <div className="min-h-screen flex items-center justify-center"><div className="animate-spin text-4xl">⏳</div></div>;
  if (!isAuthenticated) return <Redirect to="/login" />;
  return <Component {...rest} />;
}

function Router() {
  return (
    <Layout>
      <Switch>
        <Route path="/" component={Home} />
        <Route path="/login" component={Login} />
        <Route path="/register" component={Register} />
        <Route path="/dashboard">{() => <ProtectedRoute component={Dashboard} />}</Route>
        <Route path="/play-bot">{() => <ProtectedRoute component={PlayBot} />}</Route>
        <Route path="/play/:gameId">{(params) => <ProtectedRoute component={Play} params={params} />}</Route>
        <Route path="/friends">{() => <ProtectedRoute component={Friends} />}</Route>
        <Route path="/profile/:username">{(params) => <ProtectedRoute component={Profile} params={params} />}</Route>
        <Route path="/leaderboard">{() => <ProtectedRoute component={Leaderboard} />}</Route>
        <Route component={NotFound} />
      </Switch>
    </Layout>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <TooltipProvider>
          <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
            <Router />
          </WouterRouter>
          <Toaster />
        </TooltipProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
