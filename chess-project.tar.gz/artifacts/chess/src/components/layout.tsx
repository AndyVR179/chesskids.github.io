import { Link, useLocation } from "wouter";
import { useAuth } from "@/lib/auth";
import { useLogout, useGetFriendRequests } from "@workspace/api-client-react";
import { LogOut, Home, Users, Trophy, User, Bot } from "lucide-react";
import { Button } from "./ui/button";
import { cn, getInitials } from "@/lib/utils";

export function Layout({ children }: { children: React.ReactNode }) {
  const { user, isAuthenticated, refetch } = useAuth();
  const [location] = useLocation();
  const logoutMutation = useLogout();

  const { data: requests } = useGetFriendRequests({
    query: { enabled: isAuthenticated }
  });

  const handleLogout = async () => {
    await logoutMutation.mutateAsync();
    refetch();
  };

  return (
    <div className="min-h-screen flex flex-col">
      <header className="sticky top-0 z-50 w-full border-b-4 border-white/50 bg-background/80 backdrop-blur-md shadow-sm">
        <div className="max-w-7xl mx-auto px-4 h-20 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-3 group">
            <div className="w-12 h-12 bg-primary rounded-xl flex items-center justify-center shadow-md group-hover:scale-110 transition-transform rotate-3">
              <span className="text-white text-3xl">♞</span>
            </div>
            <span className="font-display text-3xl font-bold text-primary tracking-wide drop-shadow-sm">
              Chess
            </span>
          </Link>

          {isAuthenticated ? (
            <div className="flex items-center gap-2 md:gap-4">
              <nav className="hidden md:flex items-center gap-1">
                <NavButton href="/dashboard" icon={<Home size={18} />} label="Home" active={location === "/dashboard"} />
                <NavButton href="/play-bot" icon={<Bot size={18} />} label="vs Computer" active={location === "/play-bot"} />
                <NavButton href="/friends" icon={<Users size={18} />} label="Friends" active={location === "/friends"} badge={requests?.length} />
                <NavButton href="/leaderboard" icon={<Trophy size={18} />} label="Leaders" active={location === "/leaderboard"} />
              </nav>

              <div className="flex items-center gap-3 pl-4 border-l-2 border-border/50">
                <Link href={`/profile/${user?.username}`}>
                  <div
                    className="w-10 h-10 rounded-full flex items-center justify-center text-white font-bold shadow-md cursor-pointer hover:scale-105 transition-transform border-2 border-white"
                    style={{ backgroundColor: user?.avatarColor || 'var(--primary)' }}
                    title={user?.displayName}
                  >
                    {getInitials(user?.displayName || 'U')}
                  </div>
                </Link>
                <Button variant="ghost" size="icon" onClick={handleLogout} className="text-muted-foreground hover:text-destructive">
                  <LogOut size={20} />
                </Button>
              </div>
            </div>
          ) : (
            <div className="flex items-center gap-4">
              <Link href="/login">
                <Button variant="ghost" className="font-bold text-foreground">Log In</Button>
              </Link>
              <Link href="/register">
                <Button variant="secondary">Sign Up!</Button>
              </Link>
            </div>
          )}
        </div>
      </header>

      {/* Mobile Bottom Nav */}
      {isAuthenticated && (
        <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t-2 border-border p-2 px-2 flex justify-around z-50">
          <MobileNavButton href="/dashboard" icon={<Home size={22} />} active={location === "/dashboard"} />
          <MobileNavButton href="/play-bot" icon={<Bot size={22} />} active={location === "/play-bot"} />
          <MobileNavButton href="/friends" icon={<Users size={22} />} active={location === "/friends"} badge={requests?.length} />
          <MobileNavButton href="/leaderboard" icon={<Trophy size={22} />} active={location === "/leaderboard"} />
          <MobileNavButton href={`/profile/${user?.username}`} icon={<User size={22} />} active={location.startsWith("/profile")} />
        </div>
      )}

      <main className="flex-1 max-w-7xl w-full mx-auto p-4 md:p-8 mb-20 md:mb-0">
        {children}
      </main>
    </div>
  );
}

function NavButton({ href, icon, label, active, badge }: any) {
  return (
    <Link href={href}>
      <button className={cn(
        "flex items-center gap-2 px-3 py-2 rounded-xl font-bold transition-all text-sm",
        active ? "bg-primary/10 text-primary" : "text-muted-foreground hover:bg-muted hover:text-foreground"
      )}>
        {icon}
        <span>{label}</span>
        {badge > 0 && (
          <span className="bg-destructive text-white text-xs px-1.5 py-0.5 rounded-full ml-1 animate-bounce">
            {badge}
          </span>
        )}
      </button>
    </Link>
  );
}

function MobileNavButton({ href, icon, active, badge }: any) {
  return (
    <Link href={href}>
      <button className={cn(
        "flex flex-col items-center justify-center p-2 rounded-xl w-14 relative",
        active ? "text-primary" : "text-muted-foreground"
      )}>
        {icon}
        {badge > 0 && (
          <span className="absolute top-0 right-1 bg-destructive text-white text-[10px] w-4 h-4 flex items-center justify-center rounded-full">
            {badge}
          </span>
        )}
      </button>
    </Link>
  );
}
