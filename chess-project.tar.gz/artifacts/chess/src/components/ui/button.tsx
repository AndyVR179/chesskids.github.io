import * as React from "react";
import { cn } from "@/lib/utils";

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: "default" | "secondary" | "destructive" | "outline" | "ghost" | "accent";
  size?: "default" | "sm" | "lg" | "icon";
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant = "default", size = "default", ...props }, ref) => {
    const variants = {
      default: "bg-primary text-primary-foreground hover:bg-primary/90 btn-chunky",
      secondary: "bg-secondary text-secondary-foreground hover:bg-secondary/90 btn-chunky",
      accent: "bg-accent text-accent-foreground hover:bg-accent/90 btn-chunky",
      destructive: "bg-destructive text-destructive-foreground hover:bg-destructive/90 btn-chunky",
      outline: "border-2 border-border bg-white text-foreground hover:bg-muted btn-chunky",
      ghost: "hover:bg-muted hover:text-foreground",
    };

    const sizes = {
      default: "h-12 px-6 py-2 text-lg font-bold rounded-2xl",
      sm: "h-9 px-4 text-base font-semibold rounded-xl",
      lg: "h-16 px-8 text-xl font-bold rounded-3xl",
      icon: "h-12 w-12 rounded-2xl flex items-center justify-center",
    };

    return (
      <button
        ref={ref}
        className={cn(
          "inline-flex items-center justify-center whitespace-nowrap focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 font-display",
          variants[variant],
          sizes[size],
          className
        )}
        {...props}
      />
    );
  }
);
Button.displayName = "Button";

export { Button };
