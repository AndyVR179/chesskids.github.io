import React, { useState, useEffect, useMemo } from 'react';
import { Chess, Square } from 'chess.js';
import { cn } from '@/lib/utils';
import { motion, AnimatePresence } from 'framer-motion';

interface ChessBoardProps {
  fen: string;
  isMyTurn: boolean;
  playerColor: 'white' | 'black';
  onMove: (move: { from: string; to: string; promotion?: string }) => void;
  lastMove?: string[];
  status: string;
}

const PIECE_SYMBOLS: Record<string, string> = {
  'p': '♟', 'n': '♞', 'b': '♝', 'r': '♜', 'q': '♛', 'k': '♚',
  'P': '♙', 'N': '♘', 'B': '♗', 'R': '♖', 'Q': '♕', 'K': '♔'
};

const PIECE_COLORS: Record<string, string> = {
  'w': 'drop-shadow-[0_2px_0_rgba(0,0,0,0.3)] text-white stroke-black stroke-2',
  'b': 'drop-shadow-[0_2px_0_rgba(255,255,255,0.4)] text-[#222]'
};

export function ChessBoard({ fen, isMyTurn, playerColor, onMove, status }: ChessBoardProps) {
  const [chess] = useState(new Chess());
  const [selectedSquare, setSelectedSquare] = useState<Square | null>(null);
  const [validMoves, setValidMoves] = useState<string[]>([]);

  useEffect(() => {
    try {
      chess.load(fen);
    } catch (e) {
      console.error("Invalid FEN:", fen);
    }
  }, [fen, chess]);

  const board = chess.board();
  const isFlipped = playerColor === 'black';

  const rows = isFlipped ? [0, 1, 2, 3, 4, 5, 6, 7] : [7, 6, 5, 4, 3, 2, 1, 0];
  const cols = isFlipped ? [7, 6, 5, 4, 3, 2, 1, 0] : [0, 1, 2, 3, 4, 5, 6, 7];
  const files = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'];

  const handleSquareClick = (square: Square) => {
    if (status !== 'active') return;

    // If a square is already selected, try to move
    if (selectedSquare) {
      if (validMoves.includes(square)) {
        // Check for promotion (simplistic: always queen for now)
        const piece = chess.get(selectedSquare);
        const isPromotion = piece.type === 'p' && (square[1] === '8' || square[1] === '1');
        
        onMove({
          from: selectedSquare,
          to: square,
          promotion: isPromotion ? 'q' : undefined
        });
        setSelectedSquare(null);
        setValidMoves([]);
        return;
      }
    }

    // Select piece if it belongs to current player and it's their turn
    const piece = chess.get(square);
    if (piece && piece.color === playerColor[0] && isMyTurn) {
      setSelectedSquare(square);
      const moves = chess.moves({ square, verbose: true });
      setValidMoves(moves.map(m => m.to));
    } else {
      setSelectedSquare(null);
      setValidMoves([]);
    }
  };

  return (
    <div className="w-full max-w-[600px] aspect-square mx-auto rounded-xl overflow-hidden border-[12px] border-secondary shadow-2xl relative bg-secondary">
      <div className="w-full h-full grid grid-cols-8 grid-rows-8">
        {rows.map((r) => 
          cols.map((c) => {
            const square = (files[c] + (r + 1)) as Square;
            const piece = board[r][c];
            const isLight = (r + c) % 2 !== 0;
            const isSelected = selectedSquare === square;
            const isValidMove = validMoves.includes(square);
            const isCheck = piece?.type === 'k' && piece.color === chess.turn() && chess.inCheck();

            return (
              <div
                key={square}
                onClick={() => handleSquareClick(square)}
                className={cn(
                  "relative flex items-center justify-center w-full h-full",
                  isLight ? "bg-board-light" : "bg-board-dark",
                  isSelected && "ring-inset ring-4 ring-accent bg-board-highlight",
                  isCheck && "bg-destructive/80",
                  (isMyTurn && status === 'active') ? "cursor-pointer" : "cursor-default"
                )}
              >
                {/* Square coordinate labels (optional, showing on edges) */}
                {c === (isFlipped ? 7 : 0) && (
                  <span className={cn("absolute top-1 left-1 text-[10px] md:text-xs font-bold", isLight ? "text-board-dark" : "text-board-light")}>
                    {r + 1}
                  </span>
                )}
                {r === (isFlipped ? 7 : 0) && (
                  <span className={cn("absolute bottom-0 right-1 text-[10px] md:text-xs font-bold", isLight ? "text-board-dark" : "text-board-light")}>
                    {files[c]}
                  </span>
                )}

                {/* Valid move indicator */}
                {isValidMove && !piece && (
                  <div className="w-1/3 h-1/3 rounded-full bg-black/20" />
                )}
                {isValidMove && piece && (
                  <div className="absolute inset-0 border-[6px] border-black/20 rounded-full" />
                )}

                {/* Piece */}
                <AnimatePresence>
                  {piece && (
                    <motion.div
                      layoutId={`piece-${piece.color}-${piece.type}-${square}`}
                      initial={{ scale: 0.5, opacity: 0 }}
                      animate={{ scale: 1, opacity: 1 }}
                      exit={{ scale: 0.5, opacity: 0 }}
                      transition={{ type: "spring", stiffness: 300, damping: 25 }}
                      className={cn(
                        "text-5xl md:text-6xl chess-piece flex items-center justify-center",
                        PIECE_COLORS[piece.color]
                      )}
                      style={{
                        WebkitTextStroke: '2px rgba(0,0,0,0.8)',
                        color: piece.color === 'w' ? '#fff' : '#222'
                      }}
                    >
                      {PIECE_SYMBOLS[piece.color === 'w' ? piece.type.toUpperCase() : piece.type]}
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            );
          })
        )}
      </div>

      {status !== 'active' && (
        <div className="absolute inset-0 bg-black/40 backdrop-blur-sm flex items-center justify-center z-10">
          <div className="bg-white p-6 rounded-3xl text-center transform -rotate-2 card-chunky">
            <h2 className="text-3xl text-primary font-bold mb-2">Game Over!</h2>
            <p className="text-xl font-bold text-foreground">
              {chess.isCheckmate() ? "Checkmate!" : chess.isDraw() ? "It's a draw!" : "Game Resigned"}
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
