import { useGetUserProfile } from "@workspace/api-client-react";
import { formatDistanceToNow } from "date-fns";
import { getInitials } from "@/lib/utils";

export default function Profile({ params }: { params: { username: string } }) {
  const { data: profile, isLoading, error } = useGetUserProfile(params.username);

  if (isLoading) return <div className="text-center py-20 font-bold text-2xl">Loading Profile...</div>;
  if (error || !profile) return <div className="text-center py-20 font-bold text-2xl text-destructive">User not found</div>;

  return (
    <div className="max-w-3xl mx-auto space-y-8 animate-in zoom-in-95 duration-300">
      {/* Header Profile Card */}
      <div className="bg-white rounded-[3rem] p-8 md:p-12 border-[6px] border-primary shadow-xl relative overflow-hidden">
        <div className="absolute -top-10 -right-10 text-9xl opacity-5 rotate-12">♜</div>
        
        <div className="flex flex-col md:flex-row items-center gap-8 relative z-10">
          <div 
            className="w-32 h-32 md:w-40 md:h-40 rounded-full flex items-center justify-center text-white font-black text-5xl md:text-6xl border-8 border-white shadow-lg"
            style={{ backgroundColor: profile.avatarColor }}
          >
            {getInitials(profile.displayName)}
          </div>
          <div className="text-center md:text-left">
            <h1 className="text-4xl md:text-5xl font-black text-foreground mb-2">{profile.displayName}</h1>
            <p className="text-xl font-bold text-muted-foreground mb-4">@{profile.username}</p>
            <div className="inline-flex items-center gap-2 bg-secondary/20 px-6 py-2 rounded-full border-2 border-secondary">
              <span className="text-2xl">🏆</span>
              <span className="text-2xl font-bold text-secondary-foreground">{profile.rating} Rating</span>
            </div>
          </div>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard title="Games Played" value={profile.gamesPlayed} emoji="🎲" color="bg-blue-100 text-blue-700 border-blue-300" />
        <StatCard title="Wins" value={profile.gamesWon} emoji="🎉" color="bg-green-100 text-green-700 border-green-300" />
        <StatCard title="Losses" value={profile.gamesLost} emoji="😢" color="bg-red-100 text-red-700 border-red-300" />
        <StatCard title="Draws" value={profile.gamesDraw} emoji="🤝" color="bg-yellow-100 text-yellow-700 border-yellow-300" />
      </div>
      
      <div className="text-center text-muted-foreground font-bold pt-8">
        Member since {formatDistanceToNow(new Date(profile.createdAt))} ago
      </div>
    </div>
  );
}

function StatCard({ title, value, emoji, color }: any) {
  return (
    <div className={`p-6 rounded-3xl border-4 text-center ${color} shadow-sm`}>
      <div className="text-4xl mb-2">{emoji}</div>
      <div className="text-3xl font-black mb-1">{value}</div>
      <div className="font-bold text-sm uppercase tracking-wider opacity-80">{title}</div>
    </div>
  );
}
