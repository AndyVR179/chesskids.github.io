import { useState } from "react";
import { useCreateBotGame } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

const BOTS = [
  {
    id: "easy",
    name: "Beginner Bot",
    emoji: "🤖",
    description: "Makes random moves. Perfect for your first game!",
    rating: "~500",
    color: "from-green-400 to-green-600",
    border: "border-green-400",
    badge: "EASY",
    badgeColor: "bg-green-500",
    tip: "Just play and have fun!",
  },
  {
    id: "medium",
    name: "Apprentice Bot",
    emoji: "🎮",
    description: "Tries to capture your pieces. A good challenge for beginners.",
    rating: "~900",
    color: "from-blue-400 to-blue-600",
    border: "border-blue-400",
    badge: "MEDIUM",
    badgeColor: "bg-blue-500",
    tip: "Think before every move!",
  },
  {
    id: "hard",
    name: "Knight Bot",
    emoji: "⚔️",
    description: "Looks 2 moves ahead with smart positional play. Quite tough!",
    rating: "~1200",
    color: "from-orange-400 to-orange-600",
    border: "border-orange-400",
    badge: "HARD",
    badgeColor: "bg-orange-500",
    tip: "Plan your attacks carefully.",
  },
  {
    id: "expert",
    name: "Grandmaster Bot",
    emoji: "🏆",
    description: "Looks 3 moves ahead with full piece-square table evaluation. Very strong!",
    rating: "~1600",
    color: "from-purple-500 to-purple-700",
    border: "border-purple-500",
    badge: "EXPERT",
    badgeColor: "bg-purple-600",
    tip: "Good luck — you'll need it!",
  },
];

export default function PlayBot() {
  const [selectedBot, setSelectedBot] = useState<string | null>(null);
  const [selectedColor, setSelectedColor] = useState<"white" | "black" | "random">("white");
  const [isCreating, setIsCreating] = useState(false);
  const createBotGame = useCreateBotGame();
  const { toast } = useToast();
  const [, setLocation] = useLocation();

  const handleStart = async () => {
    if (!selectedBot) {
      toast({ title: "Choose a bot!", description: "Pick a difficulty first.", variant: "destructive" });
      return;
    }
    setIsCreating(true);
    try {
      const playAsWhite =
        selectedColor === "random" ? Math.random() > 0.5 : selectedColor === "white";
      const game = await createBotGame.mutateAsync({
        data: { difficulty: selectedBot as any, playAsWhite },
      });
      setLocation(`/play/${game.id}`);
    } catch (e: any) {
      toast({ title: "Oops!", description: e.message, variant: "destructive" });
      setIsCreating(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-10 animate-in fade-in duration-500">
      {/* Header */}
      <div className="text-center">
        <h1 className="text-5xl font-black text-primary mb-2">Play vs Computer</h1>
        <p className="text-xl font-bold text-muted-foreground">Choose your opponent and your color!</p>
      </div>

      {/* Bot Selection */}
      <section>
        <h2 className="text-2xl font-bold mb-4 text-foreground">1. Pick a Bot</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {BOTS.map((bot, i) => (
            <motion.div
              key={bot.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.08 }}
              onClick={() => setSelectedBot(bot.id)}
              className={cn(
                "relative bg-white rounded-3xl border-4 p-5 cursor-pointer transition-all duration-200",
                selectedBot === bot.id
                  ? `${bot.border} shadow-xl scale-[1.02]`
                  : "border-border hover:border-muted-foreground hover:shadow-md"
              )}
            >
              {selectedBot === bot.id && (
                <div className="absolute -top-3 -right-3 w-8 h-8 bg-primary rounded-full flex items-center justify-center text-white font-bold text-lg shadow-md">
                  ✓
                </div>
              )}
              <div className="flex items-start gap-4">
                <div className={cn(
                  "w-16 h-16 rounded-2xl bg-gradient-to-br flex items-center justify-center text-4xl shrink-0",
                  bot.color
                )}>
                  {bot.emoji}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1 flex-wrap">
                    <h3 className="font-black text-lg text-foreground">{bot.name}</h3>
                    <span className={cn("text-white text-xs font-bold px-2 py-0.5 rounded-full", bot.badgeColor)}>
                      {bot.badge}
                    </span>
                  </div>
                  <p className="text-sm text-muted-foreground font-semibold mb-2">{bot.description}</p>
                  <div className="flex items-center gap-2 text-sm font-bold">
                    <span className="text-secondary">📊 Rating: {bot.rating}</span>
                    <span className="text-muted-foreground/60">•</span>
                    <span className="text-accent italic text-xs">{bot.tip}</span>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Color Selection */}
      <section>
        <h2 className="text-2xl font-bold mb-4 text-foreground">2. Pick Your Color</h2>
        <div className="flex gap-4 flex-wrap">
          {[
            { id: "white", label: "Play as White", icon: "♔", desc: "You go first!" },
            { id: "black", label: "Play as Black", icon: "♚", desc: "Bot goes first." },
            { id: "random", label: "Surprise Me!", icon: "🎲", desc: "Random color." },
          ].map((c) => (
            <button
              key={c.id}
              onClick={() => setSelectedColor(c.id as any)}
              className={cn(
                "flex-1 min-w-[140px] p-4 rounded-2xl border-4 text-center transition-all duration-150 font-bold",
                selectedColor === c.id
                  ? "border-primary bg-primary/10 shadow-md scale-105"
                  : "border-border bg-white hover:border-muted-foreground"
              )}
            >
              <div className="text-4xl mb-1">{c.icon}</div>
              <div className="text-foreground font-black">{c.label}</div>
              <div className="text-xs text-muted-foreground font-semibold mt-1">{c.desc}</div>
            </button>
          ))}
        </div>
      </section>

      {/* Start Button */}
      <div className="text-center pb-8">
        <motion.div whileTap={{ scale: 0.95 }}>
          <Button
            size="lg"
            className="text-2xl px-12 py-6 rounded-full font-black shadow-lg"
            onClick={handleStart}
            disabled={!selectedBot || isCreating}
          >
            {isCreating ? (
              <span className="flex items-center gap-3">
                <span className="animate-spin">⏳</span> Setting up game...
              </span>
            ) : (
              <span className="flex items-center gap-3">
                ♟️ Start Playing!
              </span>
            )}
          </Button>
        </motion.div>
        {!selectedBot && (
          <p className="text-muted-foreground font-bold mt-3 animate-pulse">👆 Pick a bot above first</p>
        )}
      </div>
    </div>
  );
}
