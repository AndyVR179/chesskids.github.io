import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useLogin } from "@workspace/api-client-react";
import { useAuth } from "@/lib/auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { motion } from "framer-motion";

export default function Login() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const loginMutation = useLogin();
  const { refetch } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await loginMutation.mutateAsync({ data: { username, password } });
      await refetch();
      setLocation("/dashboard");
    } catch (error: any) {
      toast({
        title: "Oops!",
        description: error?.message || "Invalid username or password",
        variant: "destructive"
      });
    }
  };

  return (
    <div className="max-w-md mx-auto mt-12 md:mt-24">
      <motion.div 
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="bg-white p-8 rounded-[2rem] card-chunky"
      >
        <div className="text-center mb-8">
          <div className="w-20 h-20 bg-primary rounded-full flex items-center justify-center mx-auto mb-4 text-white text-5xl pb-2 shadow-inner">
            ♟
          </div>
          <h1 className="text-4xl font-bold text-foreground">Welcome Back!</h1>
          <p className="text-muted-foreground mt-2 font-bold">Ready for your next match?</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <label className="font-bold text-foreground ml-2">Username</label>
            <Input 
              required
              value={username}
              onChange={e => setUsername(e.target.value)}
              placeholder="CoolKid123"
            />
          </div>
          <div className="space-y-2">
            <label className="font-bold text-foreground ml-2">Password</label>
            <Input 
              required
              type="password"
              value={password}
              onChange={e => setPassword(e.target.value)}
              placeholder="••••••••"
            />
          </div>

          <Button 
            type="submit" 
            className="w-full text-xl" 
            disabled={loginMutation.isPending}
          >
            {loginMutation.isPending ? "Logging in..." : "Log In!"}
          </Button>
        </form>

        <div className="mt-8 text-center">
          <p className="font-bold text-muted-foreground">
            Don't have an account?{" "}
            <Link href="/register" className="text-primary hover:underline">
              Sign up here!
            </Link>
          </p>
        </div>
      </motion.div>
    </div>
  );
}
