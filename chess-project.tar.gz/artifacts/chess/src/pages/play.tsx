import { useGetGame, useMakeMove, useResignGame } from "@workspace/api-client-react";
import { useAuth } from "@/lib/auth";
import { ChessBoard } from "@/components/chess-board";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { getInitials } from "@/lib/utils";
import { Flag } from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";

export default function Play({ params }: { params: { gameId: string } }) {
  const gameId = parseInt(params.gameId);
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Poll for updates every 2 seconds if game is active
  const { data: game, isLoading } = useGetGame(gameId, {
    query: {
      refetchInterval: (query) => (query.state.data?.status === 'active' ? 2000 : false)
    }
  });

  const moveMutation = useMakeMove();
  const resignMutation = useResignGame();

  if (isLoading || !game) return <div className="text-center py-20 text-2xl font-bold">Loading Board...</div>;

  const isWhite = game.whitePlayer.id === user?.id;
  const isBlack = game.blackPlayer.id === user?.id;
  const isPlayer = isWhite || isBlack;
  
  const myColor = isWhite ? 'white' : 'black';
  const opponent = isWhite ? game.blackPlayer : game.whitePlayer;
  const isMyTurn = isPlayer && game.currentTurn === myColor;

  const handleMove = async ({ from, to, promotion }: { from: string, to: string, promotion?: string }) => {
    try {
      await moveMutation.mutateAsync({
        gameId,
        data: { from, to, promotion }
      });
      queryClient.invalidateQueries({ queryKey: ['/api/games', gameId] });
    } catch (error: any) {
      toast({
        title: "Invalid Move",
        description: error.message,
        variant: "destructive"
      });
    }
  };

  const handleResign = async () => {
    if (confirm("Are you sure you want to give up?")) {
      await resignMutation.mutateAsync({ gameId });
      queryClient.invalidateQueries({ queryKey: ['/api/games', gameId] });
    }
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="flex flex-col md:flex-row gap-8 items-center md:items-start">
        
        {/* Board Section */}
        <div className="w-full md:w-2/3 order-2 md:order-1">
          {/* Opponent Info (Top) */}
          <div className="flex items-center gap-4 mb-4 bg-white p-3 rounded-2xl shadow-sm border-2 border-border">
            <div className="w-12 h-12 rounded-full flex items-center justify-center text-white font-bold" style={{ backgroundColor: opponent.avatarColor }}>
              {getInitials(opponent.displayName)}
            </div>
            <div>
              <h3 className="font-bold text-lg">{opponent.displayName}</h3>
              <p className="text-sm font-bold text-muted-foreground">Rating: {opponent.rating}</p>
            </div>
            {!isMyTurn && game.status === 'active' && (
              <div className="ml-auto flex items-center gap-2 text-accent font-bold animate-pulse">
                <span className="text-2xl">⏳</span> Thinking...
              </div>
            )}
          </div>

          <ChessBoard 
            fen={game.fen} 
            isMyTurn={isMyTurn}
            playerColor={myColor}
            onMove={handleMove}
            status={game.status}
          />

          {/* Player Info (Bottom) */}
          <div className="flex items-center gap-4 mt-4 bg-white p-3 rounded-2xl shadow-sm border-2 border-border">
            <div className="w-12 h-12 rounded-full flex items-center justify-center text-white font-bold" style={{ backgroundColor: user?.avatarColor }}>
              {getInitials(user?.displayName || 'Me')}
            </div>
            <div>
              <h3 className="font-bold text-lg">{user?.displayName} (You)</h3>
              <p className="text-sm font-bold text-muted-foreground">Rating: {user?.rating}</p>
            </div>
            {isMyTurn && game.status === 'active' && (
              <div className="ml-auto flex items-center gap-2 text-primary font-bold">
                <span className="text-2xl">🟢</span> Your Turn!
              </div>
            )}
          </div>
        </div>

        {/* Sidebar Controls */}
        <div className="w-full md:w-1/3 order-1 md:order-2 space-y-6">
          <div className="bg-white p-6 rounded-3xl border-4 border-border shadow-md">
            <h2 className="text-2xl font-bold mb-4 border-b-2 border-border pb-2">Match Status</h2>
            
            <div className="text-center py-4">
               {game.status === 'active' ? (
                 <span className="bg-primary/20 text-primary font-bold px-4 py-2 rounded-full text-lg">
                   Match in Progress
                 </span>
               ) : (
                 <span className="bg-muted text-muted-foreground font-bold px-4 py-2 rounded-full text-lg">
                   {game.result === 'draw' ? 'Draw' : `${game.result} won`}
                 </span>
               )}
            </div>

            {game.status === 'active' && isPlayer && (
              <Button 
                variant="destructive" 
                className="w-full mt-6"
                onClick={handleResign}
                disabled={resignMutation.isPending}
              >
                <Flag className="mr-2 w-5 h-5" /> Give Up
              </Button>
            )}
          </div>

          <div className="bg-white p-6 rounded-3xl border-4 border-border shadow-md h-[300px] flex flex-col">
            <h2 className="text-xl font-bold mb-4">Move History</h2>
            <div className="flex-1 overflow-y-auto space-y-2 pr-2 font-mono font-bold text-sm">
              {game.moveHistory.reduce((acc: any[], move, i) => {
                if (i % 2 === 0) acc.push([move]);
                else acc[acc.length - 1].push(move);
                return acc;
              }, []).map((pair, i) => (
                <div key={i} className="flex bg-muted/50 p-2 rounded">
                  <span className="w-8 text-muted-foreground">{i + 1}.</span>
                  <span className="flex-1 text-foreground">{pair[0]}</span>
                  <span className="flex-1 text-foreground">{pair[1] || ''}</span>
                </div>
              ))}
              {game.moveHistory.length === 0 && (
                <p className="text-muted-foreground italic">No moves yet</p>
              )}
            </div>
          </div>
        </div>

      </div>
    </div>
  );
}
