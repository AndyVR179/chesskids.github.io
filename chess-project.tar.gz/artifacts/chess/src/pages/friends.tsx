import { useState } from "react";
import { 
  useGetFriends, 
  useGetFriendRequests, 
  useSearchUsers, 
  useSendFriendRequest, 
  useAcceptFriendRequest, 
  useDeclineFriendRequest,
  useCreateGame
} from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { getInitials } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";
import { Search, UserPlus, Check, X, Swords } from "lucide-react";
import { useLocation } from "wouter";

export default function Friends() {
  const [searchQuery, setSearchQuery] = useState("");
  const { data: friends } = useGetFriends();
  const { data: requests } = useGetFriendRequests();
  const { data: searchResults } = useSearchUsers({ q: searchQuery }, { query: { enabled: searchQuery.length > 2 } });
  
  const sendReqMutation = useSendFriendRequest();
  const acceptReqMutation = useAcceptFriendRequest();
  const declineReqMutation = useDeclineFriendRequest();
  const createGameMutation = useCreateGame();
  
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [, setLocation] = useLocation();

  const handleSendRequest = async (userId: number) => {
    try {
      await sendReqMutation.mutateAsync({ data: { toUserId: userId } });
      toast({ title: "Sent!", description: "Friend request sent successfully." });
    } catch (e: any) {
      toast({ title: "Error", description: e.message, variant: "destructive" });
    }
  };

  const handleAction = async (action: 'accept' | 'decline', requestId: number) => {
    try {
      if (action === 'accept') {
        await acceptReqMutation.mutateAsync({ data: { requestId } });
      } else {
        await declineReqMutation.mutateAsync({ data: { requestId } });
      }
      queryClient.invalidateQueries({ queryKey: ['/api/friends'] });
      queryClient.invalidateQueries({ queryKey: ['/api/friends/requests'] });
    } catch (e: any) {
      toast({ title: "Error", description: e.message, variant: "destructive" });
    }
  };

  const handleChallenge = async (opponentId: number) => {
    try {
      const game = await createGameMutation.mutateAsync({ data: { opponentId, playAsWhite: Math.random() > 0.5 } });
      setLocation(`/play/${game.id}`);
    } catch (e: any) {
      toast({ title: "Couldn't start game", description: e.message, variant: "destructive" });
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-in slide-in-from-bottom-4 duration-500">
      <div className="text-center mb-8">
        <h1 className="text-5xl font-black text-primary">Friends</h1>
        <p className="text-xl font-bold text-muted-foreground">Find buddies and challenge them!</p>
      </div>

      <div className="grid md:grid-cols-2 gap-8">
        {/* Left Column: Search & Requests */}
        <div className="space-y-8">
          <div className="bg-white p-6 rounded-3xl border-4 border-secondary/50 shadow-md">
            <h2 className="text-2xl font-bold mb-4 flex items-center gap-2"><Search className="text-secondary" /> Find Players</h2>
            <Input 
              placeholder="Type a username..." 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="mb-4 border-secondary focus-visible:ring-secondary"
            />
            {searchResults && searchResults.length > 0 && (
              <div className="space-y-2 mt-4 bg-muted/30 p-4 rounded-2xl">
                {searchResults.map(user => (
                  <div key={user.id} className="flex items-center justify-between bg-white p-3 rounded-xl shadow-sm">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full flex items-center justify-center text-white font-bold" style={{ backgroundColor: user.avatarColor }}>
                        {getInitials(user.displayName)}
                      </div>
                      <div>
                        <p className="font-bold text-foreground">{user.displayName}</p>
                        <p className="text-xs font-bold text-muted-foreground">@{user.username}</p>
                      </div>
                    </div>
                    <Button size="sm" variant="accent" onClick={() => handleSendRequest(user.id)}>
                      <UserPlus size={16} />
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {requests && requests.length > 0 && (
            <div className="bg-white p-6 rounded-3xl border-4 border-destructive/30 shadow-md">
              <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
                <span className="bg-destructive text-white rounded-full w-8 h-8 flex items-center justify-center">{requests.length}</span> 
                Pending Requests
              </h2>
              <div className="space-y-3">
                {requests.map(req => (
                  <div key={req.id} className="flex items-center justify-between bg-muted/20 p-3 rounded-xl">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full flex items-center justify-center text-white font-bold" style={{ backgroundColor: req.fromUser.avatarColor }}>
                        {getInitials(req.fromUser.displayName)}
                      </div>
                      <p className="font-bold">{req.fromUser.displayName}</p>
                    </div>
                    <div className="flex gap-2">
                      <Button size="icon" variant="primary" className="h-10 w-10" onClick={() => handleAction('accept', req.id)}>
                        <Check size={20} />
                      </Button>
                      <Button size="icon" variant="destructive" className="h-10 w-10" onClick={() => handleAction('decline', req.id)}>
                        <X size={20} />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Right Column: Friends List */}
        <div className="bg-white p-6 rounded-3xl border-4 border-primary shadow-md">
          <h2 className="text-2xl font-bold mb-4 flex items-center gap-2"><span className="text-3xl">👥</span> My Friends List</h2>
          <div className="space-y-3">
            {friends?.length ? friends.map(friend => (
              <div key={friend.id} className="flex items-center justify-between bg-muted/20 p-4 rounded-2xl hover:bg-muted/40 transition-colors border-2 border-transparent hover:border-primary/20">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-full flex items-center justify-center text-white text-xl font-bold shadow-sm" style={{ backgroundColor: friend.avatarColor }}>
                    {getInitials(friend.displayName)}
                  </div>
                  <div>
                    <p className="font-bold text-lg text-foreground leading-tight">{friend.displayName}</p>
                    <p className="text-sm font-bold text-secondary">Rating: {friend.rating}</p>
                  </div>
                </div>
                <Button variant="secondary" size="sm" onClick={() => handleChallenge(friend.id)}>
                  <Swords size={16} className="mr-2"/> Play
                </Button>
              </div>
            )) : (
              <div className="text-center py-10 opacity-60">
                <p className="text-6xl mb-4">🕵️‍♂️</p>
                <p className="font-bold text-xl">It's quiet here...</p>
                <p className="font-semibold text-muted-foreground">Search for users to add them as friends!</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
