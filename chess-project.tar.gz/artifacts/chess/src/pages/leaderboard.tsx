import { useGetLeaderboard } from "@workspace/api-client-react";
import { Link } from "wouter";
import { getInitials } from "@/lib/utils";

export default function Leaderboard() {
  const { data: leaders, isLoading } = useGetLeaderboard();

  if (isLoading) return <div className="text-center py-20 font-bold text-2xl">Loading Champions...</div>;

  return (
    <div className="max-w-3xl mx-auto animate-in slide-in-from-bottom-8 duration-500">
      <div className="text-center mb-10">
        <h1 className="text-5xl md:text-6xl font-black text-secondary drop-shadow-md">Top Players 🏆</h1>
        <p className="text-xl font-bold text-muted-foreground mt-4">The best of the best!</p>
      </div>

      <div className="bg-white rounded-[2rem] border-4 border-border overflow-hidden shadow-lg">
        {leaders?.map((entry, index) => {
          const isTop3 = index < 3;
          const medals = ['🥇', '🥈', '🥉'];
          
          return (
            <Link key={entry.user.id} href={`/profile/${entry.user.username}`}>
              <div className={`
                flex items-center justify-between p-4 md:p-6 border-b-2 border-border/50 hover:bg-muted/50 cursor-pointer transition-colors
                ${index === 0 ? 'bg-yellow-50 hover:bg-yellow-100 border-b-yellow-200' : ''}
              `}>
                <div className="flex items-center gap-4 md:gap-6">
                  <div className={`text-2xl md:text-4xl font-black w-12 text-center ${isTop3 ? '' : 'text-muted-foreground'}`}>
                    {isTop3 ? medals[index] : `#${entry.rank}`}
                  </div>
                  
                  <div className="w-12 h-12 md:w-16 md:h-16 rounded-full flex items-center justify-center text-white font-bold text-xl border-4 border-white shadow-sm" style={{ backgroundColor: entry.user.avatarColor }}>
                    {getInitials(entry.user.displayName)}
                  </div>
                  
                  <div>
                    <h3 className="font-bold text-lg md:text-xl text-foreground">{entry.user.displayName}</h3>
                    <p className="text-sm font-bold text-muted-foreground">{entry.gamesPlayed} games played</p>
                  </div>
                </div>
                
                <div className="text-right">
                  <div className="text-2xl md:text-3xl font-black text-primary">{entry.rating}</div>
                  <div className="text-xs font-bold text-muted-foreground uppercase tracking-wider">Rating</div>
                </div>
              </div>
            </Link>
          );
        })}
        {leaders?.length === 0 && (
          <div className="p-10 text-center font-bold text-muted-foreground">No players yet. Be the first!</div>
        )}
      </div>
    </div>
  );
}
