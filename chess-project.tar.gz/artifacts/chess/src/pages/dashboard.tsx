import { useAuth } from "@/lib/auth";
import { useGetGames, useGetFriends } from "@workspace/api-client-react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { formatDistanceToNow } from "date-fns";
import { Swords, Plus, Bot } from "lucide-react";
import { getInitials, cn } from "@/lib/utils";

export default function Dashboard() {
  const { user } = useAuth();
  const { data: games, isLoading: gamesLoading } = useGetGames();
  const { data: friends } = useGetFriends();

  const activeGames = games?.filter(g => g.status === 'active') || [];
  const pastGames = games?.filter(g => g.status !== 'active' && g.status !== 'waiting') || [];

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      {/* Welcome Banner */}
      <div className="bg-primary/10 rounded-3xl p-8 border-4 border-primary/20 flex flex-col md:flex-row items-center justify-between gap-6">
        <div>
          <h1 className="text-4xl font-black text-foreground">Hi, {user?.displayName}! 👋</h1>
          <p className="text-xl text-muted-foreground font-bold mt-2">
            Rating: <span className="text-secondary font-black">🏆 {user?.rating}</span>
          </p>
          <div className="flex gap-4 mt-2 text-sm font-bold text-muted-foreground">
            <span className="text-primary">✔️ {user?.gamesWon} Wins</span>
            <span className="text-destructive">❌ {user?.gamesLost} Losses</span>
            <span className="text-secondary">🤝 {user?.gamesDraw} Draws</span>
          </div>
        </div>
        <div className="flex flex-col sm:flex-row gap-3 w-full md:w-auto">
          <Link href="/play-bot">
            <Button size="lg" className="w-full sm:w-auto text-lg font-black rounded-2xl">
              <Bot className="mr-2" /> vs Computer
            </Button>
          </Link>
          <Link href="/friends">
            <Button size="lg" variant="secondary" className="w-full sm:w-auto text-lg font-black rounded-2xl">
              <Swords className="mr-2" /> vs Friend
            </Button>
          </Link>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="md:col-span-2 space-y-6">
          <h2 className="text-3xl font-bold flex items-center gap-3">
            <span>⚔️</span> Active Games
          </h2>

          {gamesLoading ? (
            <div className="h-40 flex items-center justify-center"><div className="animate-spin text-4xl">⏳</div></div>
          ) : activeGames.length > 0 ? (
            <div className="grid gap-4">
              {activeGames.map(game => {
                const opponent = game.whitePlayer.id === user?.id ? game.blackPlayer : game.whitePlayer;
                return (
                  <Link key={game.id} href={`/play/${game.id}`}>
                    <div className="bg-white p-4 rounded-2xl border-4 border-border hover:border-primary transition-colors cursor-pointer flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <div className="w-12 h-12 rounded-full flex items-center justify-center text-white font-bold text-lg" style={{ backgroundColor: opponent.avatarColor }}>
                          {getInitials(opponent.displayName)}
                        </div>
                        <div>
                          <h3 className="font-bold text-lg">vs {opponent.displayName}</h3>
                          <p className="text-sm font-bold text-muted-foreground">Updated {formatDistanceToNow(new Date(game.updatedAt))} ago</p>
                        </div>
                      </div>
                      <Button variant="accent">Play Turn</Button>
                    </div>
                  </Link>
                );
              })}
            </div>
          ) : (
            <div className="bg-white/50 border-4 border-dashed border-border rounded-3xl p-8 text-center">
              <div className="text-5xl mb-4 opacity-50">😴</div>
              <h3 className="text-xl font-bold text-foreground mb-2">No active games</h3>
              <p className="text-muted-foreground font-bold mb-6">Start a new game to get playing!</p>
              <div className="flex gap-3 justify-center flex-wrap">
                <Link href="/play-bot">
                  <Button variant="default"><Bot className="mr-2 w-5 h-5" /> Play vs Computer</Button>
                </Link>
                <Link href="/friends">
                  <Button variant="outline">Play vs Friend</Button>
                </Link>
              </div>
            </div>
          )}

          {pastGames.length > 0 && (
            <>
              <h2 className="text-3xl font-bold mt-12 text-muted-foreground">Past Games</h2>
              <div className="grid gap-3">
                {pastGames.slice(0, 5).map(game => {
                  const opponent = game.whitePlayer.id === user?.id ? game.blackPlayer : game.whitePlayer;
                  const amIWhite = game.whitePlayer.id === user?.id;
                  const won = (game.result === 'white' && amIWhite) || (game.result === 'black' && !amIWhite);
                  const draw = game.result === 'draw';
                  return (
                    <Link key={game.id} href={`/play/${game.id}`}>
                      <div className="bg-white/60 p-4 rounded-xl flex items-center justify-between hover:bg-white transition-colors cursor-pointer border-2 border-transparent hover:border-border">
                        <div className="flex items-center gap-3">
                          <span className="text-2xl">{won ? '🎉' : draw ? '🤝' : '😢'}</span>
                          <span className="font-bold text-foreground">vs {opponent.displayName}</span>
                        </div>
                        <span className={cn("font-bold", won ? "text-primary" : draw ? "text-secondary" : "text-destructive")}>
                          {won ? 'Victory' : draw ? 'Draw' : 'Defeat'}
                        </span>
                      </div>
                    </Link>
                  );
                })}
              </div>
            </>
          )}
        </div>

        {/* Friends Sidebar */}
        <div>
          <div className="bg-white rounded-3xl p-6 border-4 border-border sticky top-28">
            <h2 className="text-2xl font-bold mb-6 flex justify-between items-center">
              Friends
              <Link href="/friends">
                <Button variant="ghost" size="icon" className="h-8 w-8"><Plus size={20}/></Button>
              </Link>
            </h2>
            <div className="space-y-3">
              {friends?.length ? friends.map(friend => (
                <Link key={friend.id} href={`/profile/${friend.username}`}>
                  <div className="flex items-center gap-3 hover:bg-muted p-2 -mx-2 rounded-xl cursor-pointer transition-colors">
                    <div className="w-10 h-10 rounded-full flex items-center justify-center text-white font-bold text-sm" style={{ backgroundColor: friend.avatarColor }}>
                      {getInitials(friend.displayName)}
                    </div>
                    <div>
                      <p className="font-bold text-foreground leading-tight">{friend.displayName}</p>
                      <p className="text-xs font-bold text-secondary">🏆 {friend.rating}</p>
                    </div>
                  </div>
                </Link>
              )) : (
                <div className="text-center py-4">
                  <p className="text-muted-foreground font-bold italic mb-3">No friends yet!</p>
                  <Link href="/friends">
                    <Button variant="outline" size="sm">Find Players</Button>
                  </Link>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
