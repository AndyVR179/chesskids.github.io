import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/lib/auth";
import { motion } from "framer-motion";
import { useEffect } from "react";

export default function Home() {
  const { isAuthenticated, isLoading } = useAuth();
  const [, setLocation] = useLocation();

  useEffect(() => {
    if (!isLoading && isAuthenticated) {
      setLocation("/dashboard");
    }
  }, [isAuthenticated, isLoading, setLocation]);

  if (isLoading) return null;

  return (
    <div className="min-h-[calc(100vh-80px)] flex flex-col items-center justify-center text-center px-4 overflow-hidden relative">
      {/* Decorative background elements */}
      <div className="absolute top-10 left-10 text-8xl text-primary/20 -rotate-12 animate-pulse">♞</div>
      <div className="absolute bottom-20 right-10 text-9xl text-secondary/20 rotate-12 animate-pulse delay-700">♜</div>
      <div className="absolute top-40 right-20 text-7xl text-accent/20 rotate-45 animate-bounce">♚</div>
      
      <motion.div 
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ type: "spring", bounce: 0.5 }}
        className="z-10"
      >
        <img 
          src={`${import.meta.env.BASE_URL}images/logo-mascot.png`} 
          alt="Chess Mascot" 
          className="w-48 h-48 mx-auto drop-shadow-2xl mb-8"
        />
        
        <h1 className="text-6xl md:text-8xl font-black text-primary drop-shadow-lg mb-6 tracking-tight">
          Let's Play <span className="text-secondary">Chess!</span>
        </h1>
        
        <p className="text-xl md:text-2xl font-bold text-muted-foreground max-w-2xl mx-auto mb-10">
          The most fun place to learn, play, and make friends! Are you ready for the ultimate brain challenge?
        </p>

        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
          <Link href="/register">
            <Button size="lg" className="w-full sm:w-auto text-2xl px-12 h-20 rounded-full shadow-[0_6px_0_0_#16a34a]">
              Start Playing Free!
            </Button>
          </Link>
          <Link href="/login">
            <Button variant="outline" size="lg" className="w-full sm:w-auto text-2xl px-12 h-20 rounded-full">
              I have an account
            </Button>
          </Link>
        </div>
      </motion.div>
    </div>
  );
}
