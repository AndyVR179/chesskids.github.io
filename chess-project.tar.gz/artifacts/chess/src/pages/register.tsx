import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useRegister } from "@workspace/api-client-react";
import { useAuth } from "@/lib/auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { motion } from "framer-motion";

export default function Register() {
  const [username, setUsername] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [password, setPassword] = useState("");
  const registerMutation = useRegister();
  const { refetch } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await registerMutation.mutateAsync({ 
        data: { username, displayName, password } 
      });
      await refetch();
      setLocation("/dashboard");
      toast({
        title: "Welcome to Chess!",
        description: "Your account has been created.",
      });
    } catch (error: any) {
      toast({
        title: "Oops!",
        description: error?.message || "Could not create account",
        variant: "destructive"
      });
    }
  };

  return (
    <div className="max-w-md mx-auto mt-12 md:mt-16">
      <motion.div 
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="bg-white p-8 rounded-[2rem] card-chunky border-secondary"
      >
        <div className="text-center mb-8">
          <div className="w-20 h-20 bg-secondary rounded-full flex items-center justify-center mx-auto mb-4 text-white text-5xl pb-2 shadow-inner">
            ♞
          </div>
          <h1 className="text-4xl font-bold text-foreground">Join the Fun!</h1>
          <p className="text-muted-foreground mt-2 font-bold">Create your player profile</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          <div className="space-y-2">
            <label className="font-bold text-foreground ml-2">Username (Login ID)</label>
            <Input 
              required
              value={username}
              onChange={e => setUsername(e.target.value.toLowerCase().replace(/\s/g, ''))}
              placeholder="e.g. smartknight"
            />
          </div>
          <div className="space-y-2">
            <label className="font-bold text-foreground ml-2">Display Name (What others see)</label>
            <Input 
              required
              value={displayName}
              onChange={e => setDisplayName(e.target.value)}
              placeholder="e.g. Smart Knight"
            />
          </div>
          <div className="space-y-2">
            <label className="font-bold text-foreground ml-2">Secret Password</label>
            <Input 
              required
              type="password"
              value={password}
              onChange={e => setPassword(e.target.value)}
              placeholder="••••••••"
            />
          </div>

          <Button 
            type="submit" 
            variant="secondary"
            className="w-full text-xl mt-4" 
            disabled={registerMutation.isPending}
          >
            {registerMutation.isPending ? "Creating..." : "Create Account!"}
          </Button>
        </form>

        <div className="mt-8 text-center">
          <p className="font-bold text-muted-foreground">
            Already have an account?{" "}
            <Link href="/login" className="text-secondary hover:underline">
              Log in here!
            </Link>
          </p>
        </div>
      </motion.div>
    </div>
  );
}
