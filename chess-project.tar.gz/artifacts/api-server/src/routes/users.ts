import { Router, type IRouter } from "express";
import { db, usersTable } from "@workspace/db";
import { eq, ilike, desc } from "drizzle-orm";
import { requireAuth } from "../middlewares/auth";

const router: IRouter = Router();

router.get("/users/search", requireAuth, async (req, res): Promise<void> => {
  const q = req.query.q as string;
  if (!q || q.length < 2) {
    res.json([]);
    return;
  }

  const users = await db
    .select({
      id: usersTable.id,
      username: usersTable.username,
      displayName: usersTable.displayName,
      rating: usersTable.rating,
      avatarColor: usersTable.avatarColor,
    })
    .from(usersTable)
    .where(ilike(usersTable.username, `%${q}%`))
    .limit(10);

  res.json(users);
});

router.get("/leaderboard", async (_req, res): Promise<void> => {
  const users = await db
    .select({
      id: usersTable.id,
      username: usersTable.username,
      displayName: usersTable.displayName,
      rating: usersTable.rating,
      avatarColor: usersTable.avatarColor,
      gamesPlayed: usersTable.gamesPlayed,
    })
    .from(usersTable)
    .orderBy(desc(usersTable.rating))
    .limit(20);

  const leaderboard = users.map((u, idx) => ({
    rank: idx + 1,
    user: {
      id: u.id,
      username: u.username,
      displayName: u.displayName,
      rating: u.rating,
      avatarColor: u.avatarColor,
    },
    rating: u.rating,
    gamesPlayed: u.gamesPlayed,
  }));

  res.json(leaderboard);
});

router.get("/users/:username", requireAuth, async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.username) ? req.params.username[0] : req.params.username;
  const [user] = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.username, raw.toLowerCase()))
    .limit(1);

  if (!user) {
    res.status(404).json({ error: "User not found" });
    return;
  }

  res.json({
    id: user.id,
    username: user.username,
    displayName: user.displayName,
    rating: user.rating,
    gamesPlayed: user.gamesPlayed,
    gamesWon: user.gamesWon,
    gamesLost: user.gamesLost,
    gamesDraw: user.gamesDraw,
    avatarColor: user.avatarColor,
    createdAt: user.createdAt.toISOString(),
  });
});

export default router;
