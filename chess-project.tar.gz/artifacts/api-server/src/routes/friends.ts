import { Router, type IRouter } from "express";
import { db, usersTable, friendRequestsTable, friendshipsTable } from "@workspace/db";
import { eq, and, or } from "drizzle-orm";
import { requireAuth } from "../middlewares/auth";

const router: IRouter = Router();

function userSummary(u: { id: number; username: string; displayName: string; rating: number; avatarColor: string }) {
  return {
    id: u.id,
    username: u.username,
    displayName: u.displayName,
    rating: u.rating,
    avatarColor: u.avatarColor,
  };
}

router.get("/friends", requireAuth, async (req, res): Promise<void> => {
  const me = (req as any).user;

  const friendships = await db
    .select()
    .from(friendshipsTable)
    .where(
      or(
        eq(friendshipsTable.userId1, me.id),
        eq(friendshipsTable.userId2, me.id)
      )
    );

  const friendIds = friendships.map(f => f.userId1 === me.id ? f.userId2 : f.userId1);

  if (friendIds.length === 0) {
    res.json([]);
    return;
  }

  const friends = [];
  for (const friendship of friendships) {
    const friendId = friendship.userId1 === me.id ? friendship.userId2 : friendship.userId1;
    const [friend] = await db
      .select({
        id: usersTable.id,
        username: usersTable.username,
        displayName: usersTable.displayName,
        rating: usersTable.rating,
        avatarColor: usersTable.avatarColor,
      })
      .from(usersTable)
      .where(eq(usersTable.id, friendId))
      .limit(1);
    if (friend) {
      friends.push({
        ...userSummary(friend),
        friendshipId: friendship.id,
      });
    }
  }

  res.json(friends);
});

router.get("/friends/requests", requireAuth, async (req, res): Promise<void> => {
  const me = (req as any).user;

  const requests = await db
    .select()
    .from(friendRequestsTable)
    .where(
      and(
        eq(friendRequestsTable.toUserId, me.id),
        eq(friendRequestsTable.status, "pending")
      )
    );

  const result = [];
  for (const req_ of requests) {
    const [fromUser] = await db
      .select({
        id: usersTable.id,
        username: usersTable.username,
        displayName: usersTable.displayName,
        rating: usersTable.rating,
        avatarColor: usersTable.avatarColor,
      })
      .from(usersTable)
      .where(eq(usersTable.id, req_.fromUserId))
      .limit(1);
    if (fromUser) {
      result.push({
        id: req_.id,
        fromUser: userSummary(fromUser),
        createdAt: req_.createdAt.toISOString(),
      });
    }
  }

  res.json(result);
});

router.get("/friends/status/:userId", requireAuth, async (req, res): Promise<void> => {
  const me = (req as any).user;
  const raw = Array.isArray(req.params.userId) ? req.params.userId[0] : req.params.userId;
  const targetId = parseInt(raw, 10);

  if (isNaN(targetId) || targetId === me.id) {
    res.json({ status: "none" });
    return;
  }

  const [friendship] = await db
    .select()
    .from(friendshipsTable)
    .where(
      or(
        and(eq(friendshipsTable.userId1, me.id), eq(friendshipsTable.userId2, targetId)),
        and(eq(friendshipsTable.userId1, targetId), eq(friendshipsTable.userId2, me.id))
      )
    )
    .limit(1);

  if (friendship) {
    res.json({ status: "friends", friendshipId: friendship.id });
    return;
  }

  const [sentReq] = await db
    .select()
    .from(friendRequestsTable)
    .where(
      and(
        eq(friendRequestsTable.fromUserId, me.id),
        eq(friendRequestsTable.toUserId, targetId),
        eq(friendRequestsTable.status, "pending")
      )
    )
    .limit(1);

  if (sentReq) {
    res.json({ status: "pending_sent", requestId: sentReq.id });
    return;
  }

  const [receivedReq] = await db
    .select()
    .from(friendRequestsTable)
    .where(
      and(
        eq(friendRequestsTable.fromUserId, targetId),
        eq(friendRequestsTable.toUserId, me.id),
        eq(friendRequestsTable.status, "pending")
      )
    )
    .limit(1);

  if (receivedReq) {
    res.json({ status: "pending_received", requestId: receivedReq.id });
    return;
  }

  res.json({ status: "none" });
});

router.post("/friends/send", requireAuth, async (req, res): Promise<void> => {
  const me = (req as any).user;
  const { toUserId } = req.body;

  if (!toUserId || toUserId === me.id) {
    res.status(400).json({ error: "Invalid user" });
    return;
  }

  const [targetUser] = await db.select().from(usersTable).where(eq(usersTable.id, toUserId)).limit(1);
  if (!targetUser) {
    res.status(400).json({ error: "User not found" });
    return;
  }

  const [existing] = await db
    .select()
    .from(friendRequestsTable)
    .where(
      and(
        eq(friendRequestsTable.fromUserId, me.id),
        eq(friendRequestsTable.toUserId, toUserId),
        eq(friendRequestsTable.status, "pending")
      )
    )
    .limit(1);

  if (existing) {
    res.status(400).json({ error: "Friend request already sent" });
    return;
  }

  const [alreadyFriends] = await db
    .select()
    .from(friendshipsTable)
    .where(
      or(
        and(eq(friendshipsTable.userId1, me.id), eq(friendshipsTable.userId2, toUserId)),
        and(eq(friendshipsTable.userId1, toUserId), eq(friendshipsTable.userId2, me.id))
      )
    )
    .limit(1);

  if (alreadyFriends) {
    res.status(400).json({ error: "Already friends" });
    return;
  }

  await db.insert(friendRequestsTable).values({
    fromUserId: me.id,
    toUserId,
    status: "pending",
  });

  res.status(201).json({ message: "Friend request sent" });
});

router.post("/friends/accept", requireAuth, async (req, res): Promise<void> => {
  const me = (req as any).user;
  const { requestId } = req.body;

  const [request] = await db
    .select()
    .from(friendRequestsTable)
    .where(
      and(
        eq(friendRequestsTable.id, requestId),
        eq(friendRequestsTable.toUserId, me.id),
        eq(friendRequestsTable.status, "pending")
      )
    )
    .limit(1);

  if (!request) {
    res.status(400).json({ error: "Friend request not found" });
    return;
  }

  await db
    .update(friendRequestsTable)
    .set({ status: "accepted" })
    .where(eq(friendRequestsTable.id, requestId));

  await db.insert(friendshipsTable).values({
    userId1: request.fromUserId,
    userId2: request.toUserId,
  });

  res.json({ message: "Friend request accepted" });
});

router.post("/friends/decline", requireAuth, async (req, res): Promise<void> => {
  const me = (req as any).user;
  const { requestId } = req.body;

  const [request] = await db
    .select()
    .from(friendRequestsTable)
    .where(
      and(
        eq(friendRequestsTable.id, requestId),
        eq(friendRequestsTable.toUserId, me.id),
        eq(friendRequestsTable.status, "pending")
      )
    )
    .limit(1);

  if (!request) {
    res.status(400).json({ error: "Friend request not found" });
    return;
  }

  await db
    .update(friendRequestsTable)
    .set({ status: "declined" })
    .where(eq(friendRequestsTable.id, requestId));

  res.json({ message: "Friend request declined" });
});

router.post("/friends/remove", requireAuth, async (req, res): Promise<void> => {
  const me = (req as any).user;
  const { friendshipId } = req.body;

  const [friendship] = await db
    .select()
    .from(friendshipsTable)
    .where(
      and(
        eq(friendshipsTable.id, friendshipId),
        or(
          eq(friendshipsTable.userId1, me.id),
          eq(friendshipsTable.userId2, me.id)
        )
      )
    )
    .limit(1);

  if (!friendship) {
    res.status(400).json({ error: "Friendship not found" });
    return;
  }

  await db.delete(friendshipsTable).where(eq(friendshipsTable.id, friendshipId));

  res.json({ message: "Friend removed" });
});

export default router;
