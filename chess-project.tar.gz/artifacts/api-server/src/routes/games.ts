import { Router, type IRouter } from "express";
import { Chess } from "chess.js";
import { db, usersTable, gamesTable } from "@workspace/db";
import { eq, or, desc } from "drizzle-orm";
import { requireAuth } from "../middlewares/auth";
import { getBotMove, BOT_DISPLAY_NAMES } from "../lib/bot-engine";

const router: IRouter = Router();

const BOT_USERNAME = "__bot__";

async function getOrCreateBotUser() {
  const [existing] = await db.select().from(usersTable).where(eq(usersTable.username, BOT_USERNAME)).limit(1);
  if (existing) return existing;

  const [bot] = await db.insert(usersTable).values({
    username: BOT_USERNAME,
    displayName: "Computer",
    passwordHash: "not-a-real-hash",
    rating: 1500,
    avatarColor: "#607D8B",
  }).returning();
  return bot;
}

function userSummary(u: { id: number; username: string; displayName: string; rating: number; avatarColor: string }) {
  return { id: u.id, username: u.username, displayName: u.displayName, rating: u.rating, avatarColor: u.avatarColor };
}

async function buildGameResponse(game: typeof gamesTable.$inferSelect) {
  const [white] = await db.select().from(usersTable).where(eq(usersTable.id, game.whitePlayerId)).limit(1);
  const [black] = await db.select().from(usersTable).where(eq(usersTable.id, game.blackPlayerId)).limit(1);
  let moveHistory: string[] = [];
  try { moveHistory = JSON.parse(game.moveHistory); } catch {}

  let whiteDisplay = userSummary(white!);
  let blackDisplay = userSummary(black!);

  if (game.isBot && game.botDifficulty) {
    const botName = BOT_DISPLAY_NAMES[game.botDifficulty as keyof typeof BOT_DISPLAY_NAMES] ?? "Computer";
    if (white?.username === BOT_USERNAME) whiteDisplay = { ...whiteDisplay, displayName: botName };
    if (black?.username === BOT_USERNAME) blackDisplay = { ...blackDisplay, displayName: botName };
  }

  return {
    id: game.id,
    whitePlayer: whiteDisplay,
    blackPlayer: blackDisplay,
    pgn: game.pgn,
    fen: game.fen,
    status: game.status,
    result: game.result ?? null,
    currentTurn: game.currentTurn,
    moveHistory,
    createdAt: game.createdAt.toISOString(),
    updatedAt: game.updatedAt.toISOString(),
  };
}

router.get("/games", requireAuth, async (req, res): Promise<void> => {
  const me = (req as any).user;

  const games = await db
    .select()
    .from(gamesTable)
    .where(or(eq(gamesTable.whitePlayerId, me.id), eq(gamesTable.blackPlayerId, me.id)))
    .orderBy(desc(gamesTable.updatedAt));

  const result = [];
  for (const game of games) {
    const [white] = await db.select().from(usersTable).where(eq(usersTable.id, game.whitePlayerId)).limit(1);
    const [black] = await db.select().from(usersTable).where(eq(usersTable.id, game.blackPlayerId)).limit(1);

    let whiteDisplay = userSummary(white!);
    let blackDisplay = userSummary(black!);
    if (game.isBot && game.botDifficulty) {
      const botName = BOT_DISPLAY_NAMES[game.botDifficulty as keyof typeof BOT_DISPLAY_NAMES] ?? "Computer";
      if (white?.username === BOT_USERNAME) whiteDisplay = { ...whiteDisplay, displayName: botName };
      if (black?.username === BOT_USERNAME) blackDisplay = { ...blackDisplay, displayName: botName };
    }

    result.push({
      id: game.id,
      whitePlayer: whiteDisplay,
      blackPlayer: blackDisplay,
      status: game.status,
      result: game.result ?? null,
      createdAt: game.createdAt.toISOString(),
      updatedAt: game.updatedAt.toISOString(),
    });
  }

  res.json(result);
});

router.post("/games/bot", requireAuth, async (req, res): Promise<void> => {
  const me = (req as any).user;
  const { difficulty, playAsWhite } = req.body;

  const validDifficulties = ["easy", "medium", "hard", "expert"];
  if (!difficulty || !validDifficulties.includes(difficulty)) {
    res.status(400).json({ error: "Invalid difficulty. Choose: easy, medium, hard, or expert" });
    return;
  }

  const bot = await getOrCreateBotUser();
  const isWhite = playAsWhite !== false;
  const whiteId = isWhite ? me.id : bot.id;
  const blackId = isWhite ? bot.id : me.id;

  const chess = new Chess();

  const [game] = await db.insert(gamesTable).values({
    whitePlayerId: whiteId,
    blackPlayerId: blackId,
    pgn: chess.pgn(),
    fen: chess.fen(),
    status: "active",
    currentTurn: "white",
    moveHistory: "[]",
    isBot: true,
    botDifficulty: difficulty,
  }).returning();

  // If player chose black, bot goes first as white
  if (!isWhite) {
    const botMove = getBotMove(chess.fen(), difficulty);
    if (botMove) {
      chess.move(botMove);
      let mh: string[] = [];
      try { mh = JSON.parse(game.moveHistory); } catch {}
      mh.push(botMove.san);

      const [updated] = await db.update(gamesTable).set({
        pgn: chess.pgn(),
        fen: chess.fen(),
        currentTurn: "black",
        moveHistory: JSON.stringify(mh),
      }).where(eq(gamesTable.id, game.id)).returning();

      const response = await buildGameResponse(updated);
      res.status(201).json(response);
      return;
    }
  }

  const response = await buildGameResponse(game);
  res.status(201).json(response);
});

router.post("/games", requireAuth, async (req, res): Promise<void> => {
  const me = (req as any).user;
  const { opponentId, playAsWhite } = req.body;

  if (!opponentId) {
    res.status(400).json({ error: "opponentId required" });
    return;
  }

  const [opponent] = await db.select().from(usersTable).where(eq(usersTable.id, opponentId)).limit(1);
  if (!opponent) {
    res.status(400).json({ error: "Opponent not found" });
    return;
  }

  const isWhite = playAsWhite !== false;
  const whiteId = isWhite ? me.id : opponentId;
  const blackId = isWhite ? opponentId : me.id;

  const chess = new Chess();

  const [game] = await db.insert(gamesTable).values({
    whitePlayerId: whiteId,
    blackPlayerId: blackId,
    pgn: chess.pgn(),
    fen: chess.fen(),
    status: "active",
    currentTurn: "white",
    moveHistory: "[]",
    isBot: false,
  }).returning();

  const response = await buildGameResponse(game);
  res.status(201).json(response);
});

router.get("/games/:gameId", requireAuth, async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.gameId) ? req.params.gameId[0] : req.params.gameId;
  const gameId = parseInt(raw, 10);

  const [game] = await db.select().from(gamesTable).where(eq(gamesTable.id, gameId)).limit(1);
  if (!game) {
    res.status(404).json({ error: "Game not found" });
    return;
  }

  const response = await buildGameResponse(game);
  res.json(response);
});

router.post("/games/:gameId/move", requireAuth, async (req, res): Promise<void> => {
  const me = (req as any).user;
  const raw = Array.isArray(req.params.gameId) ? req.params.gameId[0] : req.params.gameId;
  const gameId = parseInt(raw, 10);

  const [game] = await db.select().from(gamesTable).where(eq(gamesTable.id, gameId)).limit(1);
  if (!game) {
    res.status(404).json({ error: "Game not found" });
    return;
  }

  if (game.status !== "active") {
    res.status(400).json({ error: "Game is not active" });
    return;
  }

  const isWhite = game.whitePlayerId === me.id;
  const isBlack = game.blackPlayerId === me.id;
  if (!isWhite && !isBlack) {
    res.status(403).json({ error: "Not a player in this game" });
    return;
  }

  if ((game.currentTurn === "white" && !isWhite) || (game.currentTurn === "black" && !isBlack)) {
    res.status(400).json({ error: "Not your turn" });
    return;
  }

  const { from, to, promotion } = req.body;

  const chess = new Chess(game.fen);
  let move;
  try {
    move = chess.move({ from, to, promotion: promotion || undefined });
  } catch {
    res.status(400).json({ error: "Invalid move" });
    return;
  }

  if (!move) {
    res.status(400).json({ error: "Invalid move" });
    return;
  }

  let moveHistory: string[] = [];
  try { moveHistory = JSON.parse(game.moveHistory); } catch {}
  moveHistory.push(move.san);

  let newTurn = game.currentTurn === "white" ? "black" : "white";
  let status = "active";
  let result: string | null = null;

  if (chess.isGameOver()) {
    status = "completed";
    if (chess.isCheckmate()) result = game.currentTurn;
    else if (chess.isDraw() || chess.isStalemate() || chess.isInsufficientMaterial() || chess.isThreefoldRepetition()) result = "draw";
  }

  // Apply bot move automatically if it's a bot game and game is still active
  if (status === "active" && game.isBot && game.botDifficulty) {
    const botMove = getBotMove(chess.fen(), game.botDifficulty as any);
    if (botMove) {
      chess.move(botMove);
      moveHistory.push(botMove.san);
      newTurn = newTurn === "white" ? "black" : "white";

      if (chess.isGameOver()) {
        status = "completed";
        if (chess.isCheckmate()) result = newTurn === "white" ? "black" : "white";
        else result = "draw";
      }
    }
  }

  const [updated] = await db
    .update(gamesTable)
    .set({
      pgn: chess.pgn(),
      fen: chess.fen(),
      currentTurn: newTurn as "white" | "black",
      moveHistory: JSON.stringify(moveHistory),
      status: status as "active" | "completed",
      result,
    })
    .where(eq(gamesTable.id, gameId))
    .returning();

  if (status === "completed" && result && !game.isBot) {
    await updatePlayerRatings(game.whitePlayerId, game.blackPlayerId, result);
  }

  const response = await buildGameResponse(updated);
  res.json(response);
});

router.post("/games/:gameId/resign", requireAuth, async (req, res): Promise<void> => {
  const me = (req as any).user;
  const raw = Array.isArray(req.params.gameId) ? req.params.gameId[0] : req.params.gameId;
  const gameId = parseInt(raw, 10);

  const [game] = await db.select().from(gamesTable).where(eq(gamesTable.id, gameId)).limit(1);
  if (!game) {
    res.status(404).json({ error: "Game not found" });
    return;
  }

  if (game.status !== "active") {
    res.status(400).json({ error: "Game is not active" });
    return;
  }

  const isWhite = game.whitePlayerId === me.id;
  const isBlack = game.blackPlayerId === me.id;
  if (!isWhite && !isBlack) {
    res.status(403).json({ error: "Not a player in this game" });
    return;
  }

  const result = isWhite ? "black" : "white";

  const [updated] = await db
    .update(gamesTable)
    .set({ status: "resigned", result })
    .where(eq(gamesTable.id, gameId))
    .returning();

  if (!game.isBot) {
    await updatePlayerRatings(game.whitePlayerId, game.blackPlayerId, result);
  }

  const response = await buildGameResponse(updated);
  res.json(response);
});

async function updatePlayerRatings(whiteId: number, blackId: number, result: string) {
  const [white] = await db.select().from(usersTable).where(eq(usersTable.id, whiteId)).limit(1);
  const [black] = await db.select().from(usersTable).where(eq(usersTable.id, blackId)).limit(1);
  if (!white || !black) return;
  if (white.username === BOT_USERNAME || black.username === BOT_USERNAME) return;

  const K = 32;
  const expectedWhite = 1 / (1 + Math.pow(10, (black.rating - white.rating) / 400));
  const expectedBlack = 1 - expectedWhite;

  let scoreWhite = 0.5, scoreBlack = 0.5;
  if (result === "white") { scoreWhite = 1; scoreBlack = 0; }
  else if (result === "black") { scoreWhite = 0; scoreBlack = 1; }

  const newWhiteRating = Math.round(white.rating + K * (scoreWhite - expectedWhite));
  const newBlackRating = Math.round(black.rating + K * (scoreBlack - expectedBlack));

  await db.update(usersTable).set({
    rating: newWhiteRating,
    gamesPlayed: white.gamesPlayed + 1,
    gamesWon: white.gamesWon + (result === "white" ? 1 : 0),
    gamesLost: white.gamesLost + (result === "black" ? 1 : 0),
    gamesDraw: white.gamesDraw + (result === "draw" ? 1 : 0),
  }).where(eq(usersTable.id, whiteId));

  await db.update(usersTable).set({
    rating: newBlackRating,
    gamesPlayed: black.gamesPlayed + 1,
    gamesWon: black.gamesWon + (result === "black" ? 1 : 0),
    gamesLost: black.gamesLost + (result === "white" ? 1 : 0),
    gamesDraw: black.gamesDraw + (result === "draw" ? 1 : 0),
  }).where(eq(usersTable.id, blackId));
}

export default router;
