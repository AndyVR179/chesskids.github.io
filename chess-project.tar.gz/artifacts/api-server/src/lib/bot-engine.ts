import { Chess, Move } from "chess.js";

type Difficulty = "easy" | "medium" | "hard" | "expert";

const PIECE_VALUES: Record<string, number> = {
  p: 100, n: 320, b: 330, r: 500, q: 900, k: 20000,
};

// Piece-square tables for positional evaluation
const PAWN_TABLE = [
   0,  0,  0,  0,  0,  0,  0,  0,
  50, 50, 50, 50, 50, 50, 50, 50,
  10, 10, 20, 30, 30, 20, 10, 10,
   5,  5, 10, 25, 25, 10,  5,  5,
   0,  0,  0, 20, 20,  0,  0,  0,
   5, -5,-10,  0,  0,-10, -5,  5,
   5, 10, 10,-20,-20, 10, 10,  5,
   0,  0,  0,  0,  0,  0,  0,  0,
];

const KNIGHT_TABLE = [
  -50,-40,-30,-30,-30,-30,-40,-50,
  -40,-20,  0,  0,  0,  0,-20,-40,
  -30,  0, 10, 15, 15, 10,  0,-30,
  -30,  5, 15, 20, 20, 15,  5,-30,
  -30,  0, 15, 20, 20, 15,  0,-30,
  -30,  5, 10, 15, 15, 10,  5,-30,
  -40,-20,  0,  5,  5,  0,-20,-40,
  -50,-40,-30,-30,-30,-30,-40,-50,
];

const BISHOP_TABLE = [
  -20,-10,-10,-10,-10,-10,-10,-20,
  -10,  0,  0,  0,  0,  0,  0,-10,
  -10,  0,  5, 10, 10,  5,  0,-10,
  -10,  5,  5, 10, 10,  5,  5,-10,
  -10,  0, 10, 10, 10, 10,  0,-10,
  -10, 10, 10, 10, 10, 10, 10,-10,
  -10,  5,  0,  0,  0,  0,  5,-10,
  -20,-10,-10,-10,-10,-10,-10,-20,
];

const ROOK_TABLE = [
   0,  0,  0,  0,  0,  0,  0,  0,
   5, 10, 10, 10, 10, 10, 10,  5,
  -5,  0,  0,  0,  0,  0,  0, -5,
  -5,  0,  0,  0,  0,  0,  0, -5,
  -5,  0,  0,  0,  0,  0,  0, -5,
  -5,  0,  0,  0,  0,  0,  0, -5,
  -5,  0,  0,  0,  0,  0,  0, -5,
   0,  0,  0,  5,  5,  0,  0,  0,
];

const QUEEN_TABLE = [
  -20,-10,-10, -5, -5,-10,-10,-20,
  -10,  0,  0,  0,  0,  0,  0,-10,
  -10,  0,  5,  5,  5,  5,  0,-10,
   -5,  0,  5,  5,  5,  5,  0, -5,
    0,  0,  5,  5,  5,  5,  0, -5,
  -10,  5,  5,  5,  5,  5,  0,-10,
  -10,  0,  5,  0,  0,  0,  0,-10,
  -20,-10,-10, -5, -5,-10,-10,-20,
];

const KING_MIDGAME_TABLE = [
  -30,-40,-40,-50,-50,-40,-40,-30,
  -30,-40,-40,-50,-50,-40,-40,-30,
  -30,-40,-40,-50,-50,-40,-40,-30,
  -30,-40,-40,-50,-50,-40,-40,-30,
  -20,-30,-30,-40,-40,-30,-30,-20,
  -10,-20,-20,-20,-20,-20,-20,-10,
   20, 20,  0,  0,  0,  0, 20, 20,
   20, 30, 10,  0,  0, 10, 30, 20,
];

function getPieceTable(type: string): number[] {
  switch (type) {
    case "p": return PAWN_TABLE;
    case "n": return KNIGHT_TABLE;
    case "b": return BISHOP_TABLE;
    case "r": return ROOK_TABLE;
    case "q": return QUEEN_TABLE;
    case "k": return KING_MIDGAME_TABLE;
    default: return Array(64).fill(0);
  }
}

function squareToIndex(square: string): number {
  const file = square.charCodeAt(0) - "a".charCodeAt(0);
  const rank = parseInt(square[1]) - 1;
  return (7 - rank) * 8 + file;
}

function evaluateBoard(chess: Chess): number {
  if (chess.isCheckmate()) return chess.turn() === "w" ? -99999 : 99999;
  if (chess.isDraw() || chess.isStalemate()) return 0;

  let score = 0;
  const board = chess.board();

  for (let r = 0; r < 8; r++) {
    for (let c = 0; c < 8; c++) {
      const piece = board[r][c];
      if (!piece) continue;

      const square = String.fromCharCode("a".charCodeAt(0) + c) + (8 - r);
      const idx = squareToIndex(square);
      const table = getPieceTable(piece.type);
      const pieceVal = PIECE_VALUES[piece.type] ?? 0;

      const positional = piece.color === "w" ? table[idx] : table[63 - idx];
      const totalVal = pieceVal + positional;

      score += piece.color === "w" ? totalVal : -totalVal;
    }
  }

  return score;
}

function orderMoves(chess: Chess, moves: Move[]): Move[] {
  return moves.sort((a, b) => {
    let scoreA = 0, scoreB = 0;
    if (a.captured) scoreA += PIECE_VALUES[a.captured] ?? 0;
    if (b.captured) scoreB += PIECE_VALUES[b.captured] ?? 0;
    if (a.flags.includes("p")) scoreA += 800;
    if (b.flags.includes("p")) scoreB += 800;
    return scoreB - scoreA;
  });
}

function minimax(chess: Chess, depth: number, alpha: number, beta: number, isMaximizing: boolean): number {
  if (depth === 0 || chess.isGameOver()) return evaluateBoard(chess);

  const moves = orderMoves(chess, chess.moves({ verbose: true }));

  if (isMaximizing) {
    let maxEval = -Infinity;
    for (const move of moves) {
      chess.move(move);
      const evalScore = minimax(chess, depth - 1, alpha, beta, false);
      chess.undo();
      maxEval = Math.max(maxEval, evalScore);
      alpha = Math.max(alpha, evalScore);
      if (beta <= alpha) break;
    }
    return maxEval;
  } else {
    let minEval = Infinity;
    for (const move of moves) {
      chess.move(move);
      const evalScore = minimax(chess, depth - 1, alpha, beta, true);
      chess.undo();
      minEval = Math.min(minEval, evalScore);
      beta = Math.min(beta, evalScore);
      if (beta <= alpha) break;
    }
    return minEval;
  }
}

export function getBotMove(fen: string, difficulty: Difficulty): Move | null {
  const chess = new Chess(fen);
  const moves = chess.moves({ verbose: true });

  if (moves.length === 0) return null;

  // Easy: random move
  if (difficulty === "easy") {
    const shuffled = [...moves].sort(() => Math.random() - 0.5);
    return shuffled[0];
  }

  const isBlack = chess.turn() === "b";
  // Medium: depth 1 (evaluate immediate position)
  // Hard: depth 2 with alpha-beta
  // Expert: depth 3 with alpha-beta
  const depth = difficulty === "medium" ? 1 : difficulty === "hard" ? 2 : 3;

  let bestMove: Move | null = null;
  let bestScore = isBlack ? Infinity : -Infinity;

  const orderedMoves = orderMoves(chess, moves);

  for (const move of orderedMoves) {
    chess.move(move);
    const score = minimax(chess, depth - 1, -Infinity, Infinity, !isBlack);
    chess.undo();

    if (isBlack ? score < bestScore : score > bestScore) {
      bestScore = score;
      bestMove = move;
    }
  }

  return bestMove ?? moves[0];
}

export const BOT_DISPLAY_NAMES: Record<Difficulty, string> = {
  easy: "Bot Beginner",
  medium: "Bot Apprentice",
  hard: "Bot Knight",
  expert: "Bot Grandmaster",
};

export const BOT_EMOJIS: Record<Difficulty, string> = {
  easy: "🤖",
  medium: "🎮",
  hard: "⚔️",
  expert: "🏆",
};
