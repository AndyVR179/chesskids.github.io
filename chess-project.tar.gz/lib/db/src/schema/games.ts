import { pgTable, serial, integer, text, timestamp, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { usersTable } from "./users";

export const gamesTable = pgTable("games", {
  id: serial("id").primaryKey(),
  whitePlayerId: integer("white_player_id").notNull().references(() => usersTable.id),
  blackPlayerId: integer("black_player_id").notNull().references(() => usersTable.id),
  pgn: text("pgn").notNull().default(""),
  fen: text("fen").notNull().default("rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"),
  status: text("status").notNull().default("active"),
  result: text("result"),
  currentTurn: text("current_turn").notNull().default("white"),
  moveHistory: text("move_history").notNull().default("[]"),
  isBot: boolean("is_bot").notNull().default(false),
  botDifficulty: text("bot_difficulty"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertGameSchema = createInsertSchema(gamesTable).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertGame = z.infer<typeof insertGameSchema>;
export type Game = typeof gamesTable.$inferSelect;
